export function fieldValidator(name) {
  if (!name || name.length <= 0) return false
  return true
}


export function nameValidator(name) {
  if (!name || name.length <= 0) return "Field can't be empty."
  return ''
}

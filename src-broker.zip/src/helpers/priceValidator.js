export function priceValidator(name) {
  if (!name || name.length <= 0 || name==0) return false
  return true
}


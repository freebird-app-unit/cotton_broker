const credentials = {
    clientId: '1092885786732-mbkufs9gkblr44rd0ma0gosj1his7pj5.apps.googleusercontent.com',
    appId: '1:1092885786732:android:5c985918395a6ac6676849',
    apiKey: 'AIzaSyAh0zSYw6abqVxVzJjj9-KkOEknYqEYRfA',
    storageBucket: 'cotton-broker-25b0d.appspot.com',
    databaseURL: 'https://databasename.firebaseio.com',
    messagingSenderId: '1092885786732',
    projectId: 'cotton-broker-25b0d',
};

export default credentials